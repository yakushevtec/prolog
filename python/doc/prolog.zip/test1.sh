:
echo "sums should be 05431"
python  prolog1.py test1.pl |sum
python3 prolog1.py test1.pl |sum

